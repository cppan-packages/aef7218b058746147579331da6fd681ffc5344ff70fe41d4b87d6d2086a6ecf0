"""
    --------------------------------------
        About this viewer
    --------------------------------------

    Tiny demo viewer to view turtle graphics example scripts.

    Quickly and dirtyly assembled by Gregor Lingl.
    June, 2006

    For more information see: turtledemo - Help

    Have fun!
"""
